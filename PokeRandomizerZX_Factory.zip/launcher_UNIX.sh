#!/bin/bash
cd "$( dirname "$0" )"
java -Xmx4608M -jar PokeRandomizerZX-Factory.jar please-use-the-launcher